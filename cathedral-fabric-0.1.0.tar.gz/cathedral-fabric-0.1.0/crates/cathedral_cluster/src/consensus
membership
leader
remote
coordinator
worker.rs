// stub for consensus
membership
leader
remote
coordinator
worker
