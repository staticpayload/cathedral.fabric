//! Middleware

pub struct Middleware;
pub struct MiddlewareStack;
