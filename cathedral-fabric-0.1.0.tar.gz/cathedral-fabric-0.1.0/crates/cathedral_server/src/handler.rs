//! Request handlers

pub struct Handler;
pub struct HandlerError;
