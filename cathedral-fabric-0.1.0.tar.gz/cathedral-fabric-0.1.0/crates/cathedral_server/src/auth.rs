//! Authentication

pub struct Authenticator;
pub struct AuthConfig;
pub struct AuthError;
