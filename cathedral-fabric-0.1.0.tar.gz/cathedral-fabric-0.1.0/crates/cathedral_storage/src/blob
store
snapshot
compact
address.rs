// stub for blob
store
snapshot
compact
address
