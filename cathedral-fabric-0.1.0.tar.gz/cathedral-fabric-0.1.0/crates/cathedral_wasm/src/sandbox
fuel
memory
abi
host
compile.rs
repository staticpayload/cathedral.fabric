// stub for sandbox
fuel
memory
abi
host
compile
