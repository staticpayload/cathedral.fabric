// stub for network
failure
node
seed
harness
record
