// stub for engine
diff
state
trace
snapshot
