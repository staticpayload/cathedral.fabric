// stub for event
encoding
chain
stream
cursor
