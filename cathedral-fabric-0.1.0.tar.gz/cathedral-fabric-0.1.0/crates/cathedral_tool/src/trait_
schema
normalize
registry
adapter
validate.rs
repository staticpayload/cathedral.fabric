// stub for trait_
schema
normalize
registry
adapter
validate
